<?php
/**
 * Template Name: Home
 *
 * @package tuskilometrosnosdanvida
 */

 get_header(); ?>

    <section class="hero">
        <div class="hero__title">
            <h1>
                6 <span class="number">a</span> Carrera solidaria por la lucha contra el cancer infantil <span class="title">Tus kilómetros nos dan vida</span> 
            </h1>
            <span class="place">Parque del Alamillo</span>
            <span class="date">Sevilla, 28 de octubre de 2018</span>
        </div>
        <div class="hero__buttons">
            <button class="primary"><a href="#">Inscríbete</a></button>
            <button class="primary-cto"><a href="#">Dorsal 0</a></button>
        </div>
    </section>

 <?php
 get_footer();
